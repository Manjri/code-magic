#ifndef tests_hpp
#define tests_hpp

#include "rangeAllocator.h"

void runTests(RangeAllocator& ra);

#endif /* tests_hpp */
